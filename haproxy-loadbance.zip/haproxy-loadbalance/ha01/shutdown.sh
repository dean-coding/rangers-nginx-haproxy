killall haproxy
